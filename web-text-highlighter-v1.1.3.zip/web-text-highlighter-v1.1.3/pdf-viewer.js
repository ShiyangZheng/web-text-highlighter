// pdf-viewer.js  ·  module script for pdf-viewer.html

const $ = id => document.getElementById(id);

// ── Status ────────────────────────────────────────────────────
function showStatus(msg, isError = false) {
  const bar = $('status-bar');
  bar.className = 'visible' + (isError ? ' error' : '');
  $('status-text').textContent = msg;
  $('spinner').style.display = isError ? 'none' : '';
}
function hideStatus() { $('status-bar').className = ''; }

// ── State ─────────────────────────────────────────────────────
let pdfDoc   = null;
let scale    = 1.25;
let pdfjsLib = null;
const ZOOM_STEP = 0.15;
const ZOOM_MIN  = 0.25;
const ZOOM_MAX  = 4.0;

// ── Load PDF.js ───────────────────────────────────────────────
try {
  pdfjsLib = await import(chrome.runtime.getURL('lib/pdf.mjs'));
  pdfjsLib.GlobalWorkerOptions.workerPort =
    new Worker(chrome.runtime.getURL('lib/pdf.worker.mjs'), { type: 'module' });
} catch (e) {
  showStatus('Failed to load PDF.js: ' + e.message, true);
  console.error(e);
}

updateZoomDisplay();

// ── Load shared scripts ───────────────────────────────────────
async function loadScript(url) {
  return new Promise((ok, fail) => {
    if (document.querySelector(`script[src="${url}"]`)) { ok(); return; }
    const s = document.createElement('script');
    s.src = url; s.onload = ok; s.onerror = fail;
    document.head.appendChild(s);
  });
}

async function loadSharedServices() {
  if (window._sharedLoaded) return;
  showStatus('Loading services…');
  await loadScript(chrome.runtime.getURL('lib/idiomParser.js'));
  await loadScript(chrome.runtime.getURL('lib/aiService.js'));
  await loadScript(chrome.runtime.getURL('lib/idiomUI.js'));

  const parser = new IdiomParser();
  await new Promise(res => chrome.storage.sync.get(['idiomCsv'], async r => {
    if (r.idiomCsv && r.idiomCsv.length > 0) {
      await parser.loadFromFile(r.idiomCsv);
    } else {
      try {
        const url = chrome.runtime.getURL('idiom.csv');
        const resp = await fetch(url);
        const csv = await resp.text();
        await parser.loadFromFile(csv);
      } catch (e) {
        await parser.loadFromFile(parser.getDefaultIdioms());
      }
    }
    res();
  }));
  window.idiomParser = parser;
  window.aiService   = new AIService();
  window.currentHighlightedElement = null;
  window.highlightedElements = new Map();
  window._sharedLoaded = true;
}

// ── Zoom helpers ──────────────────────────────────────────────
function updateZoomDisplay() {
  $('zoom-display').textContent = Math.round(scale * 100) + '%';
}

async function setZoom(newScale) {
  scale = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, newScale));
  updateZoomDisplay();
  if (pdfDoc) {
    const visIdx = getVisibleIdx();
    showStatus('Re-rendering…');
    await renderAllPages();
    hideStatus();
    // Restore scroll position to same page
    document.querySelectorAll('.page-wrapper')[visIdx]
      ?.scrollIntoView({ block: 'start' });
  }
}

async function fitToWidth() {
  if (!pdfDoc) return;
  const page     = await pdfDoc.getPage(1);
  const vp       = page.getViewport({ scale: 1 });
  const padding  = 48; // 24px each side
  const newScale = ($('pdf-container').clientWidth - padding) / vp.width;
  await setZoom(newScale);
}

// ── Open PDF ──────────────────────────────────────────────────
async function openPDF(source, name) {
  if (!pdfjsLib) { showStatus('PDF.js not loaded', true); return; }
  showStatus('Loading PDF…');
  $('drop-zone').style.display = 'none';

  try {
    await loadSharedServices();

    let docParams;
    if (source instanceof ArrayBuffer) {
      docParams = { data: source };
    } else if (typeof source === 'string') {
      if (source.startsWith('file://') || source.startsWith('chrome-extension://')) {
        showStatus('Fetching PDF…');
        const resp = await fetch(source);
        if (!resp.ok) throw new Error(`Fetch failed: ${resp.status}`);
        docParams = { data: await resp.arrayBuffer() };
      } else {
        docParams = { url: source };
      }
    } else {
      docParams = source;
    }

    docParams.worker = new pdfjsLib.PDFWorker({
      port: new Worker(chrome.runtime.getURL('lib/pdf.worker.mjs'), { type: 'module' })
    });

    pdfDoc = await pdfjsLib.getDocument(docParams).promise;
    $('file-name').textContent = decodeURIComponent(name || 'PDF').replace(/%20/g, ' ');

    // Fit to width on first load
    const firstPage = await pdfDoc.getPage(1);
    const vp1 = firstPage.getViewport({ scale: 1 });
    scale = Math.min(ZOOM_MAX, ($('pdf-container').clientWidth - 48) / vp1.width);
    updateZoomDisplay();

    updateNav();
    await renderAllPages();
    hideStatus();
    setupSelectionToolbar();
  } catch (e) {
    console.error('openPDF error:', e);
    showStatus('Error: ' + e.message, true);
  }
}

// ── Render all pages ──────────────────────────────────────────
async function renderAllPages() {
  const container = $('pdf-container');
  container.querySelectorAll('.page-wrapper').forEach(el => el.remove());

  const dpr = window.devicePixelRatio || 1;

  for (let p = 1; p <= pdfDoc.numPages; p++) {
    showStatus(`Rendering page ${p} / ${pdfDoc.numPages}…`);

    const page     = await pdfDoc.getPage(p);
    const viewport = page.getViewport({ scale });

    const wrapper = document.createElement('div');
    wrapper.className    = 'page-wrapper';
    wrapper.dataset.page = p;
    wrapper.style.width  = Math.floor(viewport.width)  + 'px';
    wrapper.style.height = Math.floor(viewport.height) + 'px';
    wrapper.style.animationDelay = (p - 1) * 0.03 + 's';

    // Hi-DPI canvas
    const canvas = document.createElement('canvas');
    canvas.width        = Math.floor(viewport.width  * dpr);
    canvas.height       = Math.floor(viewport.height * dpr);
    canvas.style.width  = Math.floor(viewport.width)  + 'px';
    canvas.style.height = Math.floor(viewport.height) + 'px';
    wrapper.appendChild(canvas);

    // PDF.js textLayer
    const textLayerDiv = document.createElement('div');
    textLayerDiv.className  = 'textLayer';
    textLayerDiv.style.width  = Math.floor(viewport.width)  + 'px';
    textLayerDiv.style.height = Math.floor(viewport.height) + 'px';
    wrapper.appendChild(textLayerDiv);

    // Page badge
    const badge = document.createElement('div');
    badge.className   = 'page-badge';
    badge.textContent = p;
    wrapper.appendChild(badge);

    container.appendChild(wrapper);

    // Render canvas at hi-DPI scale
    await page.render({
      canvasContext: canvas.getContext('2d'),
      viewport: page.getViewport({ scale: scale * dpr })
    }).promise;

    // Official textLayer
    const textContent = await page.getTextContent();
    await new pdfjsLib.TextLayer({
      textContentSource: textContent,
      container: textLayerDiv,
      viewport
    }).render();

    // Apply italic/bold based on PDF font metadata
    applyFontStyles(textLayerDiv, textContent);

    highlightIdiomsInTextLayer(textLayerDiv);
  }
}

// ── Idiom auto-highlight ──────────────────────────────────────
function highlightIdiomsInTextLayer(div) {
  if (!window.idiomParser) return;
  const spans = Array.from(div.querySelectorAll('span'));
  if (!spans.length) return;

  let fullText = '', charMap = [];
  spans.forEach(span => {
    const t = span.textContent;
    for (let i = 0; i < t.length; i++) charMap.push(span);
    charMap.push(null);
    fullText += t + ' ';
  });

  const found = window.idiomParser.findIdiomsInText(fullText);
  if (!found?.length) return;

  found.forEach(idiom => {
    const needle = idiom.matchedForm.toLowerCase();
    let from = 0, idx;
    while ((idx = fullText.toLowerCase().indexOf(needle, from)) !== -1) {
      const touched = new Set();
      for (let i = idx; i < idx + idiom.matchedForm.length; i++)
        if (charMap[i]) touched.add(charMap[i]);

      const sentence = window.extractSentence?.(fullText, idiom.matchedForm) || idiom.matchedForm;

      touched.forEach(span => {
        if (span.classList.contains('idiom-highlight')) return;
        span.classList.add('idiom-highlight', idiom.matchType || 'exact');
        span.setAttribute('data-idiom',            idiom.idiom);
        span.setAttribute('data-definition',       idiom.definition || '');
        span.setAttribute('data-matched-form',     idiom.matchedForm);
        span.setAttribute('data-match-type',       idiom.matchType || 'exact');
        span.setAttribute('data-user-highlighted', 'false');
        span.setAttribute('data-sentence',         sentence);
        span.style.cursor = 'pointer';
        // Green highlight for auto-detected idioms in PDF
        span.style.borderBottom = '2px solid #22c55e';
        span.style.background   = 'rgba(34,197,94,0.2)';
        span.addEventListener('click', e => {
          e.stopPropagation();
          window.currentHighlightedElement = span;
          window.showIdiomPopup?.(span);
        });
      });

      from = idx + needle.length;
    }
  });
}

// ── Font style preservation ───────────────────────────────────
function applyFontStyles(textLayerDiv, textContent) {
  // PDF.js TextLayer renders spans with role="presentation", one per text item.
  // We use three signals to detect italic/bold:
  //   1. fontName from textContent.items (PDF internal name, e.g. "Times-BoldItalic")
  //   2. textContent.styles[fontName].fontFamily (CSS font-family PDF.js resolved)
  //   3. The span's own style.fontFamily (what PDF.js actually set on the DOM element)
  // We match spans to items by position order (PDF.js renders them in item order).

  const spans = Array.from(textLayerDiv.querySelectorAll('span[role="presentation"]'));
  const items = (textContent.items || []).filter(item => typeof item.str === 'string');
  const styles = textContent.styles || {};

  // Helper: detect italic/bold from any font string
  function detectFont(str) {
    if (!str) return { italic: false, bold: false };
    const s = str.toLowerCase();
    const italic = s.includes('italic') || s.includes('oblique') ||
                   s.includes('-it') || s.includes('_it') ||
                   s.includes('slant');
    const bold = s.includes('bold') || s.includes('black') ||
                 s.includes('heavy') || s.includes('demi');
    return { italic, bold };
  }

  let spanIdx = 0;
  items.forEach(item => {
    if (item.str === '') return; // skip empty items (EOL markers etc.)
    const span = spans[spanIdx++];
    if (!span) return;

    const fontName   = item.fontName || '';
    const styleEntry = styles[fontName] || {};
    const fontFamily = styleEntry.fontFamily || '';
    const spanFamily = span.style.fontFamily || '';

    // Check all three signals
    const fromName   = detectFont(fontName);
    const fromFamily = detectFont(fontFamily);
    const fromSpan   = detectFont(spanFamily);

    const isItalic = fromName.italic || fromFamily.italic || fromSpan.italic;
    const isBold   = fromName.bold   || fromFamily.bold   || fromSpan.bold;

    if (isItalic) span.style.fontStyle  = 'italic';
    if (isBold)   span.style.fontWeight = 'bold';

    // Store for downstream use
    span.dataset.fontName = fontName;
    span.dataset.isItalic = String(isItalic);
    span.dataset.isBold   = String(isBold);
  });
}

// ── Selection toolbar ─────────────────────────────────────────
function setupSelectionToolbar() {
  if (document.getElementById('pdf-sel-toolbar')) return;

  const toolbar = document.createElement('div');
  toolbar.id = 'pdf-sel-toolbar';
  toolbar.style.cssText = [
    'display:none', 'position:fixed', 'z-index:9500',
    'background:#fff', 'border:3px solid #333', 'border-radius:12px',
    'box-shadow:4px 4px 0 rgb(0,0,0)', 'padding:8px 12px',
    'gap:8px', 'align-items:center', 'flex-wrap:nowrap'
  ].join(';');
  toolbar.innerHTML = `
    <button class="pcb" data-color="yellow" title="Yellow">🟡</button>
    <button class="pcb" data-color="green"  title="Green">🟢</button>
    <button class="pcb" data-color="blue"   title="Blue">🔵</button>
    <button class="pcb" data-color="purple" title="Purple">🟣</button>
    <button class="pcb" data-color="red"    title="Red">🔴</button>
    <span class="pdiv">|</span>
    <button class="pub" data-style="straight" title="Straight">╱</button>
    <button class="pbb" title="Bold">𝐁</button>
    <button class="pub" data-style="double"   title="Wave">〰️</button>
    <span class="pdiv">|</span>
    <button class="pab" id="pdf-sel-anki"   title="Add to Anki">➕</button>
    <button class="pab" id="pdf-sel-notion" title="Save to Notion">📘</button>
    <button class="pab" id="pdf-sel-cancel" title="Cancel">✕</button>
  `;
  document.body.appendChild(toolbar);

  const BS = 'border:2px solid #333;border-radius:8px;padding:5px 10px;cursor:pointer;font-weight:bold;background:#f8f8f8;color:#999;font-size:13px;transition:all 0.15s;';
  toolbar.querySelectorAll('.pcb,.pub,.pbb,.pab').forEach(b => {
    b.style.cssText = BS;
    b.addEventListener('mouseenter', () => { b.style.transform='translateY(-2px)'; b.style.boxShadow='2px 2px 0 #333'; });
    b.addEventListener('mouseleave', () => { b.style.transform=''; b.style.boxShadow=''; });
    b.addEventListener('mousedown',  () => { b.style.color='#2563eb'; b.style.background='#eff6ff'; });
    b.addEventListener('mouseup',    () => { b.style.color='#999';    b.style.background='#f8f8f8'; });
  });
  toolbar.querySelectorAll('.pdiv').forEach(d => {
    d.style.cssText = 'color:#ccc;font-weight:bold;padding:0 2px;';
  });

  let lastText = '', lastRange = null;

  function positionToolbar(sel) {
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    const tw = toolbar.offsetWidth || 400;
    let left = rect.left + rect.width / 2 - tw / 2;
    let top  = rect.top - 52;
    left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
    if (top < 8) top = rect.bottom + 8;
    toolbar.style.left = left + 'px';
    toolbar.style.top  = top  + 'px';
    toolbar.style.display = 'flex';
  }

  document.addEventListener('mouseup', () => {
    const sel  = window.getSelection();
    const text = sel?.toString().trim();
    if (!text || text.length < 2) { toolbar.style.display = 'none'; return; }
    if (!sel.anchorNode?.parentElement?.closest('.textLayer,.page-wrapper')) {
      toolbar.style.display = 'none'; return;
    }

    // Suppress browser native selection mini-toolbar:
    // save range → clear selection → restore via JS (browser won't show its bar)
    const savedRange = sel.getRangeAt(0).cloneRange();
    sel.removeAllRanges();

    Promise.resolve().then(() => {
      const freshSel = window.getSelection();
      freshSel.addRange(savedRange);
      lastText  = text;
      lastRange = savedRange;
      positionToolbar(freshSel);
    });
  });

  document.addEventListener('mousedown', e => {
    if (!toolbar.contains(e.target)) toolbar.style.display = 'none';
  });

  function applyHighlight(type, style) {
    if (!lastRange || !lastText) return;
    toolbar.style.display = 'none';
    const sentence = window.extractSentence?.(
      lastRange.commonAncestorContainer?.textContent || '', lastText) || lastText;
    const spanClass = type === 'background' ? `highlight-${style}` :
                      type === 'bold'       ? 'bold-text' : `underline-${style}`;
    try {
      let mark;
      if (window.makeHighlightSpan) {
        mark = window.makeHighlightSpan(
          { idiom: lastText, definition: 'User highlighted' },
          lastText, sentence, true, style
        );
        mark.classList.remove(...mark.classList);
        mark.className = `idiom-highlight user-highlighted ${spanClass}`;
      } else {
        mark = document.createElement('mark');
        mark.textContent = lastText;
        mark.className = `idiom-highlight user-highlighted ${spanClass}`;
        mark.setAttribute('data-idiom', lastText);
        mark.setAttribute('data-definition', 'User highlighted');
        mark.setAttribute('data-user-highlighted', 'true');
        mark.setAttribute('data-sentence', sentence);
        mark.addEventListener('click', ev => {
          ev.stopPropagation();
          window.currentHighlightedElement = mark;
          window.showIdiomPopup?.(mark);
        });
      }
      mark.style.color = 'inherit';
      mark.setAttribute('data-highlight-type', type);
      mark.setAttribute('data-highlight-style', style);
      lastRange.deleteContents();
      lastRange.insertNode(mark);
      window.getSelection()?.removeAllRanges();
      window.showNotification?.('✨ Applied!', 'success');
    } catch(e) {
      console.warn('PDF highlight insert:', e);
      window.showNotification?.('❌ Selection error', 'error');
    }
  }

  toolbar.querySelectorAll('.pcb').forEach(btn =>
    btn.addEventListener('click', e => { e.stopPropagation(); applyHighlight('background', btn.dataset.color); }));
  toolbar.querySelectorAll('.pub').forEach(btn =>
    btn.addEventListener('click', e => { e.stopPropagation(); applyHighlight('underline', btn.dataset.style); }));
  toolbar.querySelector('.pbb').addEventListener('click', e => { e.stopPropagation(); applyHighlight('bold', 'bold'); });

  document.getElementById('pdf-sel-anki')?.addEventListener('click', e => {
    e.stopPropagation();
    toolbar.style.display = 'none';
    chrome.runtime.sendMessage({
      action: 'addToAnki',
      data: {
        idiom: lastText, definition: 'PDF Highlighted', matchedForm: lastText,
        sentence: lastRange?.commonAncestorContainer?.textContent?.substring(0,200) || lastText,
        url: location.href, title: document.title, userHighlighted: true
      }
    }, r => window.showNotification?.(r?.success ? '✅ Added to Anki!' : '❌ ' + (r?.error||'Failed')));
  });

  document.getElementById('pdf-sel-notion')?.addEventListener('click', async e => {
    e.stopPropagation();
    toolbar.style.display = 'none';
    const el = window.currentHighlightedElement;
    let aiData = null;
    if (el) { try { const c = el.getAttribute('data-ai-cache'); if(c) aiData = JSON.parse(c); } catch(_){} }
    chrome.runtime.sendMessage({
      action: 'addToNotion',
      data: {
        idiom: lastText, definition: 'PDF Highlighted', matchedForm: lastText,
        sentence: lastRange?.commonAncestorContainer?.textContent?.substring(0,200) || lastText,
        note: el?.getAttribute('data-note') || '',
        aiData, url: location.href, title: document.title, userHighlighted: true
      }
    }, r => window.showNotification?.(r?.success ? '✅ Saved to Notion!' : '❌ ' + (r?.error||'Failed')));
  });

  document.getElementById('pdf-sel-cancel')?.addEventListener('click', e => {
    e.stopPropagation();
    toolbar.style.display = 'none';
  });
}

// ── Navigation ────────────────────────────────────────────────
function updateNav() {
  const n = pdfDoc?.numPages || 0;
  $('btn-prev').disabled = false;
  $('btn-next').disabled = false;
  $('page-total').textContent = `/ ${n}`;
  $('page-input').max   = n;
  $('page-input').value = 1;
}

function getVisibleIdx() {
  const ws  = [...document.querySelectorAll('.page-wrapper')];
  const top = $('pdf-container').getBoundingClientRect().top;
  for (let i = 0; i < ws.length; i++)
    if (ws[i].getBoundingClientRect().bottom > top + 10) return i;
  return 0;
}

function scrollToPage(idx) {
  document.querySelectorAll('.page-wrapper')[idx]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

$('btn-prev').addEventListener('click', () => scrollToPage(Math.max(0, getVisibleIdx() - 1)));
$('btn-next').addEventListener('click', () => {
  const ws = document.querySelectorAll('.page-wrapper');
  scrollToPage(Math.min(ws.length - 1, getVisibleIdx() + 1));
});

$('pdf-container').addEventListener('scroll', () => {
  const w = document.querySelectorAll('.page-wrapper')[getVisibleIdx()];
  if (w) $('page-input').value = w.dataset.page;
}, { passive: true });

$('page-input').addEventListener('change', e => {
  const n = parseInt(e.target.value);
  if (n >= 1 && n <= pdfDoc?.numPages) scrollToPage(n - 1);
});
$('page-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') e.target.blur();
});

// ── Zoom controls ─────────────────────────────────────────────
$('zoom-in').addEventListener('click',  () => setZoom(scale + ZOOM_STEP));
$('zoom-out').addEventListener('click', () => setZoom(scale - ZOOM_STEP));
$('zoom-fit').addEventListener('click', fitToWidth);

// Ctrl + scroll wheel
$('pdf-container').addEventListener('wheel', e => {
  if (!e.ctrlKey && !e.metaKey) return;
  e.preventDefault();
  setZoom(scale + (e.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP));
}, { passive: false });

// Keyboard shortcuts
document.addEventListener('keydown', e => {
  const tag = document.activeElement?.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA') return;
  if ((e.ctrlKey || e.metaKey) && e.key === '=') { e.preventDefault(); setZoom(scale + ZOOM_STEP); }
  if ((e.ctrlKey || e.metaKey) && e.key === '-') { e.preventDefault(); setZoom(scale - ZOOM_STEP); }
  if ((e.ctrlKey || e.metaKey) && e.key === '0') { e.preventDefault(); fitToWidth(); }
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown')
    scrollToPage(Math.min((pdfDoc?.numPages || 1) - 1, getVisibleIdx() + 1));
  if (e.key === 'ArrowLeft' || e.key === 'ArrowUp')
    scrollToPage(Math.max(0, getVisibleIdx() - 1));
});

// ── File input ────────────────────────────────────────────────
$('btn-open-file').addEventListener('click', () => $('file-input').click());

function handleFileInput(file) {
  if (!file) return;
  if (file.type && file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    showStatus('Please select a PDF file', true); return;
  }
  const r = new FileReader();
  r.onload  = e => openPDF(e.target.result, file.name);
  r.onerror = () => showStatus('Failed to read file', true);
  r.readAsArrayBuffer(file);
}

$('file-input').addEventListener('change',      e => handleFileInput(e.target.files[0]));
$('drop-file-input').addEventListener('change', e => handleFileInput(e.target.files[0]));

const dz = $('drop-zone');
document.addEventListener('dragover',  e => { e.preventDefault(); dz.classList.add('drag-over'); });
document.addEventListener('dragleave', e => { if (!e.relatedTarget) dz.classList.remove('drag-over'); });
document.addEventListener('drop', e => {
  e.preventDefault(); dz.classList.remove('drag-over'); handleFileInput(e.dataTransfer.files[0]);
});

// ── Auto-load from ?file= ─────────────────────────────────────
const fileUrl = new URLSearchParams(location.search).get('file');
if (fileUrl) openPDF(fileUrl, decodeURIComponent(fileUrl.split('/').pop()));
