// ── PDF Auto-redirect ─────────────────────────────────────────────────────────
// Chrome's built-in PDF renderer blocks content scripts.
// We intercept navigation to local/remote PDFs and redirect to our own viewer.

const PDF_VIEWER = chrome.runtime.getURL('pdf-viewer.html');

function isPdfUrl(url) {
  if (!url) return false;
  try {
    const u = new URL(url);
    // Already in our viewer → skip
    if (url.startsWith(PDF_VIEWER)) return false;
    return u.pathname.toLowerCase().endsWith('.pdf') ||
           u.href.toLowerCase().includes('.pdf?') ||
           u.href.toLowerCase().includes('.pdf#');
  } catch { return false; }
}

// Intercept completed navigations to PDF files
chrome.webNavigation.onCompleted.addListener(details => {
  if (details.frameId !== 0) return;          // main frame only
  if (!isPdfUrl(details.url)) return;

  const viewerUrl = PDF_VIEWER + '?file=' + encodeURIComponent(details.url);
  chrome.tabs.update(details.tabId, { url: viewerUrl });
}, {
  url: [
    { urlMatches: '\\.pdf$' },
    { urlMatches: '\\.pdf\\?' },
    { urlMatches: '\\.pdf#' },
    { urlPrefix: 'file://' }
  ]
});

// Create right-click menus on install
chrome.runtime.onInstalled.addListener((details) => {
  // Open onboarding page on first install
  if (details.reason === 'install') {
    chrome.tabs.create({
      url: chrome.runtime.getURL('onboarding.html')
    });
  }

  // Main highlight menu
  chrome.contextMenus.create({
    id: "highlight-idiom",
    title: "✨ Highlight as Idiom",
    contexts: ["selection"]
  });
  
  // Remove highlight menu (appears when clicking on highlighted text)
  chrome.contextMenus.create({
    id: "remove-highlight",
    title: "🗑️ Remove Highlight",
    contexts: ["all"]
  });
  
  // Initialize default settings
  chrome.storage.sync.get({
    // Anki settings
    ankiEnabled: true,
    ankiUrl: 'http://localhost:8765',
    defaultDeck: 'English Idioms',
    defaultModel: 'Basic',
    
    // AI settings
    aiEnabled: true,
    aiProvider: 'openai',
    aiApiKey: '',
    customApiUrl: '',
    customModel: '',
    customPrompt: '',

    // Notion settings
    notionEnabled: false,
    notionApiKey: '',
    notionDatabaseId: '',
    
    // CSV data
    idiomCsv: ''
  });
});

// Handle right-click menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "highlight-idiom" && info.selectionText) {
    chrome.tabs.sendMessage(tab.id, {
      action: 'highlightSelection',
      text: info.selectionText
    });
  }
  
  if (info.menuItemId === "remove-highlight") {
    chrome.tabs.sendMessage(tab.id, {
      action: 'removeHighlight'
    });
  }
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'addToAnki':
      addToAnki(request.data)
        .then(result => sendResponse({success: true, result}))
        .catch(error => sendResponse({success: false, error: error.message}));
      break;

    case 'addToNotion':
      addToNotion(request.data)
        .then(result => sendResponse({success: true, result}))
        .catch(error => sendResponse({success: false, error: error.message}));
      break;

    case 'getSettings':
      getSettings().then(settings => sendResponse(settings));
      break;

    case 'openSettings':
      chrome.runtime.openOptionsPage();
      sendResponse({success: true});
      break;

    case 'generateAIExplanation':
      generateAIExplanation(request.data)
        .then(explanation => sendResponse({success: true, explanation}))
        .catch(error => sendResponse({success: false, error: error.message}));
      break;

    case 'baiduTranslate':
      fetch(request.url)
        .then(r => r.json())
        .then(data => sendResponse({data}))
        .catch(err => sendResponse({error: err.message}));
      break;

    case 'openEdgeSettings':
      // edge:// URLs can only be opened from background service worker
      chrome.tabs.create({ url: 'edge://settings/appearance' })
        .then(() => sendResponse({ success: true }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      break;

    case 'learningModeManualTrigger':
      // Forward to active tab's content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'learningModeManualTrigger' })
            .then(() => sendResponse({ success: true }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        } else {
          sendResponse({ success: false, error: 'No active tab' });
        }
      });
      break;

    default:
      sendResponse({success: false, error: 'Unknown action'});
      break;
  }
  // Always return true to keep the message channel open for async responses
  return true;
});

// Handle keyboard shortcuts from manifest.json
chrome.commands.onCommand.addListener((command) => {
  if (command === 'manual-learning-card') {
    // Forward to active tab's content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'learningModeManualTrigger' });
      }
    });
  }
});

// Add to Anki function
async function addToAnki(data) {
  const settings = await getSettings();
  
  if (!settings.ankiEnabled) {
    throw new Error('Anki integration is disabled. Please enable it in settings.');
  }
  
  // Prepare AI insights for Anki card
  let aiText = '';
  if (data.aiData) {
    aiText = `
<h3>🤖 AI Insights</h3>
<p><strong>Meaning:</strong> ${data.aiData.meaning || ''}</p>
<p><strong>Example:</strong> ${data.aiData.example || ''}</p>
<p><strong>Usage:</strong> ${data.aiData.usage || ''}</p>
${data.aiData.origin ? `<p><strong>Origin:</strong> ${data.aiData.origin}</p>` : ''}
${data.aiData.similar ? `<p><strong>Similar:</strong> ${data.aiData.similar}</p>` : ''}
    `;
  }
  
  const note = {
    deckName: settings.defaultDeck || 'English Idioms',
    modelName: settings.defaultModel || 'Basic',
    fields: {
      Front: `<h1>${data.idiom}</h1>${data.userHighlighted ? '<p><em>✨ User Highlighted</em></p>' : ''}`,
      Back: `
<div style="font-family: Arial, sans-serif;">
  <h2>${data.idiom}</h2>
  
  <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 15px 0;">
    <h3>📖 Definition</h3>
    <p>${data.definition || 'User highlighted phrase'}</p>
  </div>
  
  <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 15px 0;">
    <h3>📝 Context</h3>
    <p><em>${data.sentence || 'No context available'}</em></p>
  </div>
  
  ${aiText}
  
  <div style="background: #fff3cd; padding: 15px; border-radius: 8px; margin: 15px 0;">
    <h3>📌 Your Notes</h3>
    <p>${data.note || 'No notes added'}</p>
  </div>
  
  <hr>
  <p style="color: #666; font-size: 12px;">
    Source: <a href="${data.url}">${data.title}</a><br>
    Added: ${new Date().toLocaleString()}
  </p>
</div>
      `
    },
    tags: ['idiom', data.userHighlighted ? 'user-highlighted' : 'auto-detected', data.aiData ? 'ai-enhanced' : 'basic'].filter(Boolean),
    options: {
      allowDuplicate: false,
      duplicateScope: 'deck'
    }
  };
  
  const response = await fetch(settings.ankiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action: 'addNote',
      version: 6,
      params: {
        note: note
      }
    })
  });
  
  const result = await response.json();
  
  if (result.error) {
    throw new Error(result.error);
  }
  
  return result.result;
}

// Add to Notion function
async function addToNotion(data) {
  const settings = await getSettings();
  
  if (!settings.notionEnabled || !settings.notionApiKey || !settings.notionDatabaseId) {
    throw new Error('Notion is not configured properly. Please check your settings.');
  }

  const ai = data.aiData || {};

  // Helper: rich_text property
  const rt = (content) => ({
    rich_text: [{ text: { content: (content || '').substring(0, 2000) } }]
  });

  // Build all properties matching the exact Notion DB schema
  const properties = {
    'Idiom': {
      title: [{ text: { content: data.idiom || '' } }]
    },
    'Definition': rt(data.definition || 'User highlighted phrase'),
    'Context':    rt(data.sentence  || 'No context available'),
    'URL': {
      url: data.url || null
    },
    'Source':     rt(data.title || ''),
    'Type': {
      select: { name: data.userHighlighted ? 'User Highlighted' : 'Auto Detected' }
    },
    'Date': {
      date: { start: new Date().toISOString() }
    },
    'Status': {
      select: { name: 'To Review' }
    }
  };

  // AI fields
  if (ai.meaning)  properties['AI Meaning']  = rt(ai.meaning);
  if (ai.example)  properties['AI Example']  = rt(ai.example);
  if (ai.usage)    properties['AI Usage']    = rt(ai.usage);
  if (ai.origin)   properties['AI Origin']   = rt(ai.origin);
  if (ai.similar)  properties['AI Similar']  = rt(ai.similar);

  // Notes
  if (data.note)   properties['Notes'] = rt(data.note);

  // Tags multi-select
  const tags = [data.userHighlighted ? 'User Highlighted' : 'Auto Detected'];
  if (ai.meaning) tags.push('AI Enhanced');
  properties['Tags'] = {
    multi_select: tags.map(name => ({ name }))
  };

  const requestBody = {
    parent: { database_id: settings.notionDatabaseId },
    properties
  };

  try {
    const response = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${settings.notionApiKey}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || `Notion API error ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Notion API error:', error);
    throw error;
  }
}

// Get settings from storage
function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({
      // Anki settings
      ankiEnabled: true,
      ankiUrl: 'http://localhost:8765',
      defaultDeck: 'English Idioms',
      defaultModel: 'Basic',
      
      // AI settings
      aiEnabled: true,
      aiProvider: 'openai',
      aiApiKey: '',
      customApiUrl: '',
      customModel: '',
      customPrompt: '',

      // Notion settings
      notionEnabled: false,
      notionApiKey: '',
      notionDatabaseId: '',
      
      // CSV data
      idiomCsv: ''
    }, resolve);
  });
}

// ── Provider configurations ──────────────────────────────────
const AI_PROVIDER_CONFIGS = {
  openai: {
    url: 'https://api.openai.com/v1/chat/completions',
    defaultModel: 'gpt-4o-mini',
    authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
    parseResponse: (data) => data.choices?.[0]?.message?.content,
  },
  anthropic: {
    url: 'https://api.anthropic.com/v1/messages',
    defaultModel: 'claude-3-haiku-20240307',
    authHeader: (key) => ({ 'x-api-key': key, 'anthropic-version': '2023-06-01' }),
    buildBody: (model, prompt) => ({
      model,
      max_tokens: 600,
      messages: [{ role: 'user', content: prompt }],
    }),
    parseResponse: (data) => data.content?.[0]?.text,
  },
  gemini: {
    urlFn: (key, model) => `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    defaultModel: 'gemini-1.5-flash',
    authHeader: () => ({}),
    buildBody: (model, prompt) => ({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { maxOutputTokens: 600, temperature: 0.7 },
    }),
    parseResponse: (data) => data.candidates?.[0]?.content?.parts?.[0]?.text,
  },
  deepseek: {
    url: 'https://api.deepseek.com/chat/completions',
    defaultModel: 'deepseek-chat',
    authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
    parseResponse: (data) => data.choices?.[0]?.message?.content,
  },
  mistral: {
    url: 'https://api.mistral.ai/v1/chat/completions',
    defaultModel: 'mistral-small-latest',
    authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
    parseResponse: (data) => data.choices?.[0]?.message?.content,
  },
  groq: {
    url: 'https://api.groq.com/openai/v1/chat/completions',
    defaultModel: 'llama-3.1-8b-instant',
    authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
    parseResponse: (data) => data.choices?.[0]?.message?.content,
  },
  openrouter: {
    url: 'https://openrouter.ai/api/v1/chat/completions',
    defaultModel: 'openai/gpt-4o-mini',
    authHeader: (key) => ({ 'Authorization': `Bearer ${key}`, 'HTTP-Referer': 'https://github.com/web-text-highlighter' }),
    parseResponse: (data) => data.choices?.[0]?.message?.content,
  },
  ollama: {
    url: 'http://127.0.0.1:11434/v1/chat/completions',
    defaultModel: 'gemma3:4b',
    authHeader: () => ({ 'Authorization': 'Bearer ollama' }),
    buildBody: (model, prompt) => ({
      model,
      messages: [{ role: 'user', content: prompt }],
      stream: false,
    }),
    parseResponse: (data) => {
      return data.choices?.[0]?.message?.content
        || data.message?.content
        || data.choices?.[0]?.text
        || (typeof data.content === 'string' ? data.content : null)
        || null;
    },
  },
  custom: {
    url: null, // uses customApiUrl from settings
    defaultModel: '',
    authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
    parseResponse: (data) => data.choices?.[0]?.message?.content || data.content || data.response,
  },
};

const DEFAULT_PROMPT = `Analyze the following English phrase or idiom.

Phrase: "{idiom}"
Context: "{context}"

Respond ONLY in this exact format (one field per line):
MEANING: <concise definition>
USAGE: <when/how to use it, register, typical situations>
EXAMPLE: <one original example sentence>
ORIGIN: <brief etymology or origin, or "Unknown">
SIMILAR: <2-3 similar expressions, comma-separated>`;

// Generate AI Explanation — multi-provider
async function generateAIExplanation(data) {
  const settings = await getSettings();

  if (!settings.aiEnabled) {
    throw new Error('AI is disabled. Please enable it in settings.');
  }

  const provider = settings.aiProvider || 'openai';
  const apiKey   = settings.aiApiKey || '';
  const cfg      = AI_PROVIDER_CONFIGS[provider] || AI_PROVIDER_CONFIGS.custom;

  // Ollama and custom URL don't require a key
  const requiresKey = !['ollama'].includes(provider);
  if (requiresKey && !apiKey) {
    throw new Error(`API key not configured for ${provider}. Please add it in AI Settings.`);
  }

  const model  = settings.customModel || cfg.defaultModel;
  const prompt = (settings.customPrompt || DEFAULT_PROMPT)
    .replace(/\{idiom\}/g,   data.idiom   || '')
    .replace(/\{context\}/g, data.sentence || 'No context');

  // Determine URL
  let url;
  if (cfg.urlFn) {
    url = cfg.urlFn(apiKey, model);
  } else if (provider === 'custom' || provider === 'ollama') {
    url = settings.customApiUrl || cfg.url;
    if (!url) throw new Error('Custom API URL not set. Please add it in AI Settings.');
  } else {
    url = settings.customApiUrl || cfg.url;
  }

  // Build request body
  let body;
  if (cfg.buildBody) {
    body = cfg.buildBody(model, prompt);
  } else {
    body = {
      model,
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 600,
      temperature: 0.7,
    };
  }

  // Build headers
  const headers = {
    'Content-Type': 'application/json',
    ...cfg.authHeader(apiKey),
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      let errMsg = `HTTP ${response.status}`;
      try {
        const errJson = await response.json();
        errMsg = errJson.error?.message || errJson.message || errMsg;
      } catch (_) {}
      throw new Error(errMsg);
    }

    const result = await response.json();
    console.log('[WTH] AI raw response:', JSON.stringify(result).substring(0, 500));
    const explanation = cfg.parseResponse(result);

    if (!explanation) throw new Error('Empty response from AI provider');
    return explanation;

  } catch (error) {
    console.error('[WTH] AI API error:', error);
    throw error;
  }
}