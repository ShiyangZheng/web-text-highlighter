// Content script for Idiom Highlighter
console.log('✅ Idiom Highlighter content script loaded');

// Global variables
let idiomParser = null;
let aiService = null;
let notionService = null;
let currentHighlightedElement = null;
let highlightedElements = new Map();
let selectionTimeout = null;

// Initialize on load - route to PDF or web highlighter
(async function init() {
  if (isPDFPage()) {
    console.log('📄 PDF detected, initializing PDF viewer...');
    await initializePDFViewer();
  } else {
    await initializeWebHighlighter();
  }
})();

// Load all services
async function loadServices() {
  try {
    // Initialize parser
    idiomParser = new IdiomParser();
    window.idiomParser = idiomParser;
    
    // Load idioms from storage or use default
    await loadIdioms();
    
    // Initialize AI service
    aiService = new AIService();
    window.aiService = aiService;
    
    // Initialize Notion service
    notionService = new NotionService();
    window.notionService = notionService;
    
    console.log('✅ All services loaded');
  } catch (error) {
    console.error('Failed to load services:', error);
  }
}

// Load idioms from storage
async function loadIdioms() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['idiomCsv'], async (result) => {
      if (result.idiomCsv && result.idiomCsv.length > 0) {
        await idiomParser.loadFromFile(result.idiomCsv);
        console.log('✅ Loaded custom idioms from storage');
      } else {
        // Fetch bundled idiom.csv as default
        try {
          const url = chrome.runtime.getURL('idiom.csv');
          const resp = await fetch(url);
          const csv = await resp.text();
          await idiomParser.loadFromFile(csv);
          console.log('✅ Loaded default idioms from idiom.csv');
        } catch (e) {
          await idiomParser.loadFromFile(idiomParser.getDefaultIdioms());
          console.log('✅ Loaded fallback hardcoded idioms');
        }
      }
      resolve();
    });
  });
}

// Setup mutation observer for dynamic content
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    // Check if new text nodes were added
    let shouldRehighlight = false;
    
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.TEXT_NODE && node.textContent.trim().length > 0) {
            shouldRehighlight = true;
            break;
          }
          if (node.nodeType === Node.ELEMENT_NODE && node.textContent.trim().length > 0) {
            shouldRehighlight = true;
            break;
          }
        }
      }
      if (shouldRehighlight) break;
    }
    
    if (shouldRehighlight) {
      setTimeout(() => autoHighlightIdioms(), 1000);
    }
  });
  
  // On React SPA pages (LinkedIn etc.), don't observe mutations to avoid hydration loops
  const isReactSPA = !!document.querySelector('[data-reactroot]') || 
                     !!document.querySelector('#react-root') ||
                     typeof window.__NEXT_DATA__ !== 'undefined';
  if (!isReactSPA) {
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// Check if a DOM element is managed by React (has fiber internals)
function isReactManaged(el) {
  if (!el) return false;
  // Walk up to check for React fiber keys on any ancestor (up to 5 levels)
  let node = el;
  for (let i = 0; i < 5 && node && node !== document.body; i++) {
    const keys = Object.keys(node);
    for (const key of keys) {
      if (key.startsWith('__reactFiber') || key.startsWith('__reactInternalInstance') ||
          key.startsWith('__reactProps')) {
        return true;
      }
    }
    node = node.parentElement;
  }
  return false;
}

// Auto-highlight known idioms
async function autoHighlightIdioms() {
  if (!idiomParser) return;
  
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: (node) => {
        const el = node.parentElement;
        if (!el) return NodeFilter.FILTER_REJECT;
        // Skip extension-owned nodes
        if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
        if (el.classList.contains('idiom-highlight')) return NodeFilter.FILTER_REJECT;
        if (el.closest('.idiom-popup') || el.closest('.selection-toolbar')) return NodeFilter.FILTER_REJECT;
        if (el.closest('#wth-learning-widget')) return NodeFilter.FILTER_REJECT;
        // Skip React-managed nodes to avoid hydration errors
        if (isReactManaged(el)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );
  
  const textNodes = [];
  while (walker.nextNode()) {
    textNodes.push(walker.currentNode);
  }
  
  textNodes.forEach(textNode => {
    const text = textNode.textContent;
    const foundIdioms = idiomParser.findIdiomsInText(text);
    
    if (foundIdioms.length > 0) {
      wrapTextNode(textNode, foundIdioms, text, false);
    }
  });
}

// Wrap text node with highlight spans
function wrapTextNode(textNode, idioms, fullText, isUserHighlighted = false, highlightStyle = 'yellow') {
  const parent = textNode.parentNode;
  const text = textNode.textContent;
  const fragment = document.createDocumentFragment();
  
  let lastIndex = 0;
  
  idioms.sort((a, b) => {
    return text.indexOf(a.matchedForm) - text.indexOf(b.matchedForm);
  });
  
  idioms.forEach(idiom => {
    const index = text.indexOf(idiom.matchedForm, lastIndex);
    if (index === -1) return;
    
    // Add text before the idiom
    if (index > lastIndex) {
      fragment.appendChild(document.createTextNode(text.substring(lastIndex, index)));
    }
    
    // Create highlight span
    const span = makeHighlightSpan(idiom, idiom.matchedForm, fullText, isUserHighlighted, highlightStyle);
    fragment.appendChild(span);
    
    // Store in map for potential removal
    highlightedElements.set(span, {
      id: idiom.idiom,
      text: idiom.matchedForm,
      isUserHighlighted
    });
    
    lastIndex = index + idiom.matchedForm.length;
  });
  
  // Add remaining text
  if (lastIndex < text.length) {
    fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
  }
  
  // Final guard: don't replace if parent is React-managed
  if (isReactManaged(parent)) return;
  parent.replaceChild(fragment, textNode);
}

// Extract full sentence containing the text
function extractSentence(text, target) {
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  for (let sentence of sentences) {
    if (sentence.includes(target)) {
      return sentence.trim();
    }
  }
  
  // If no sentence found, return context window
  const index = text.indexOf(target);
  if (index === -1) return target;
  
  const start = Math.max(0, index - 50);
  const end = Math.min(text.length, index + target.length + 50);
  return '...' + text.substring(start, end) + '...';
}

// Handle user-selected text highlighting
async function highlightSelection(selectedText, highlightStyle = 'yellow') {
  try {
    await loadServices();
    
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    
    const range = selection.getRangeAt(0);
    const span = makeHighlightSpan(
      { idiom: selectedText, definition: 'User highlighted phrase' },
      selectedText,
      extractSentence(range.commonAncestorContainer.textContent || '', selectedText),
      true,
      highlightStyle
    );
    
    // Replace selection with highlighted span
    range.deleteContents();
    range.insertNode(span);
    selection.removeAllRanges();
    
    // Store in map
    highlightedElements.set(span, {
      id: selectedText,
      text: selectedText,
      isUserHighlighted: true
    });
    
    showNotification('✨ Text highlighted', 'success');
    
  } catch (error) {
    console.error('Highlight error:', error);
    showNotification('❌ Failed to highlight: ' + error.message, 'error');
  }
}

// Remove current highlight
function removeHighlight() {
  if (currentHighlightedElement && 
      currentHighlightedElement.classList.contains('user-highlighted')) {
    const text = document.createTextNode(currentHighlightedElement.textContent);
    currentHighlightedElement.parentNode.replaceChild(text, currentHighlightedElement);
    highlightedElements.delete(currentHighlightedElement);
    currentHighlightedElement = null;
    showNotification('✅ Highlight removed', 'success');
  }
}

// 检查是否支持 PDF
function isPDFPage() {
  return window.location.href.toLowerCase().includes('.pdf') ||
         document.contentType === 'application/pdf' ||
         window.location.pathname.toLowerCase().endsWith('.pdf');
}

// 初始化函数 - web 普通网页
async function initializeWebHighlighter() {
  await loadServices();
  setupMutationObserver();
  setupSelectionListener();
  console.log('✅ Web highlighter initialized with selection toolbar');
}

async function initializePDFViewer() {
  // PDF pages are handled by pdf-viewer.html (our built-in viewer).
  // background.js auto-redirects, but if content.js somehow runs on a PDF
  // page before the redirect completes, we redirect manually here.
  const viewerUrl = chrome.runtime.getURL('pdf-viewer.html') +
                    '?file=' + encodeURIComponent(window.location.href);
  window.location.replace(viewerUrl);
}

function showPDFErrorMessage(message) {
  const div = document.createElement('div');
  div.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: #fee2e2;
    color: #dc2626;
    padding: 12px 24px;
    border-radius: 8px;
    border: 1px solid #fecaca;
    z-index: 10000;
    font-family: sans-serif;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  `;
  div.textContent = '📄 PDF Error: ' + message;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 5000);
}

// Setup selection listener for toolbar
function setupSelectionListener() {
  document.addEventListener('mouseup', (e) => {
    // Don't trigger on highlights or toolbar
    if (e.target.closest('.idiom-highlight') || 
        e.target.closest('.selection-toolbar') ||
        e.target.closest('.idiom-popup') ||
        e.target.closest('.wth-lang-picker') ||
        e.target.closest('.wth-revert-menu')) {
      return;
    }

    // Clear previous timeout
    if (selectionTimeout) {
      clearTimeout(selectionTimeout);
    }

    // Suppress the browser's native selection mini-toolbar:
    // Capture the range, clear the selection (kills the native bar before
    // it renders), then immediately restore it programmatically.
    // Chrome will not show its native bar for a JS-restored selection.
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && sel.toString().trim().length > 0) {
      const savedRange = sel.getRangeAt(0).cloneRange();
      sel.removeAllRanges();
      // Re-add on next microtask so the browser sees a clean slate
      Promise.resolve().then(() => {
        const freshSel = window.getSelection();
        freshSel.addRange(savedRange);
        clearTimeout(selectionTimeout);
        selectionTimeout = setTimeout(() => {
          showSelectionToolbar();
        }, 80);
      });
    }
  });
  
  // Hide toolbar when clicking elsewhere
  document.addEventListener('mousedown', (e) => {
    if (!e.target.closest('.selection-toolbar') && 
        !e.target.closest('.idiom-highlight') &&
        !e.target.closest('.wth-lang-picker') &&
        !e.target.closest('.wth-revert-menu')) {
      hideSelectionToolbar();
    }
  });

  // Suppress browser's native "Look Up / Search / Share" context mini-bar
  // that appears on some platforms (macOS, iOS, Android) after selection.
  // We capture selectionchange and immediately clear+restore the range
  // before the browser has a chance to render its own UI.
  document.addEventListener('selectionchange', () => {
    // Only act when selection is non-empty and our toolbar isn't already up
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.toString().trim().length === 0) return;
    if (document.querySelector('.selection-toolbar')) return; // our toolbar shown
    // The actual suppression happens in the mouseup handler via removeAllRanges
  });

  // Hide toolbar on scroll
  let scrollTimeout;
  document.addEventListener('scroll', () => {
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(() => {
      hideSelectionToolbar();
    }, 100);
  });
}

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'highlightSelection':
      highlightSelection(request.text, request.style || 'yellow');
      sendResponse({success: true});
      break;
      
    case 'removeHighlight':
      removeHighlight();
      sendResponse({success: true});
      break;
      
    case 'getStats':
      const highlights = document.querySelectorAll('.idiom-highlight');
      const autoHighlights = document.querySelectorAll('.idiom-highlight:not([data-user-highlighted="true"])');
      const userHighlights = document.querySelectorAll('.idiom-highlight[data-user-highlighted="true"]');
      
      const uniqueIdioms = new Set();
      highlights.forEach(el => uniqueIdioms.add(el.getAttribute('data-idiom')));
      
      sendResponse({
        count: highlights.length,
        autoCount: autoHighlights.length,
        userCount: userHighlights.length,
        uniqueCount: uniqueIdioms.size,
        idioms: Array.from(highlights).map(el => ({
          idiom: el.getAttribute('data-idiom'),
          matched: el.textContent,
          type: el.getAttribute('data-user-highlighted') === 'true' ? 'user' : el.getAttribute('data-match-type')
        }))
      });
      break;
      
    case 'refresh':
      autoHighlightIdioms();
      sendResponse({success: true});
      break;
      
    case 'clearHighlights':
      document.querySelectorAll('.idiom-highlight').forEach(el => {
        const text = document.createTextNode(el.textContent);
        el.parentNode.replaceChild(text, el);
      });
      highlightedElements.clear();
      sendResponse({success: true});
      break;

    case 'learningModeToggle':
      initOrToggleLearningMode(request.enabled);
      sendResponse({success: true});
      break;

    case 'learningModePreview':
      initOrToggleLearningMode(true, true);
      sendResponse({success: true});
      break;

    case 'learningModeUpdate':
      if (window.wthLearningMode) window.wthLearningMode.updateSettings(request.settings || {});
      sendResponse({success: true});
      break;

    case 'learningModeManualTrigger':
      if (window.wthLearningMode) {
        window.wthLearningMode._manualTrigger();
      }
      sendResponse({success: true});
      break;
  }
  
  return true;
});

// Debug function for testing
window.testAI = async function(idiom = 'kick the bucket', context = 'He finally kicked the bucket yesterday.') {
  const settings = await getSettings();
  if (!settings.aiApiKey && settings.aiProvider !== 'ollama') return 'No API key';

  await aiService.init({
    apiKey: settings.aiApiKey,
    apiUrl: settings.customApiUrl,
    model: settings.customModel,
    customPrompt: settings.customPrompt
  });
  
  return await aiService.getEnhancedInfo(idiom, context);
};

// Export for debugging
window.debug = {
  highlightedElements,
  currentHighlightedElement,
  parser: idiomParser,
  ai: aiService
};
// ── Learning Mode ──────────────────────────────────────────────────────────

async function initOrToggleLearningMode(enable, preview = false) {
  const lm = window.wthLearningMode;
  if (!lm) return;

  // Always stop first to clear timers/widget before reinitialising
  lm.stop();

  const settings = await getSettingsForLM();
  const idioms   = await getIdiomsForLM();

  await lm.init(idioms, {
    fontSize:      settings.lmFontSize      || 14,
    bgColor:       settings.lmBgColor       || '#1e293b',
    textColor:     settings.lmTextColor     || '#f1f5f9',
    accentColor:   settings.lmAccentColor   || '#6366f1',
    scheduleMode:  settings.lmScheduleMode  || 'fsrs',
    intervalValue: settings.lmIntervalValue || 30,
    intervalUnit:  settings.lmIntervalUnit  || 'minutes',
  });

  if (enable || preview) {
    lm.start();
  }
  // if !enable and !preview → stay stopped (lm.stop() already called above)
}

function getSettingsForLM() {
  return new Promise(resolve => {
    chrome.storage.sync.get({
      learningModeEnabled: false,
      lmScheduleMode: 'fsrs',
      lmIntervalValue: 30,
      lmIntervalUnit: 'minutes',
      lmFontSize: 14,
      lmBgColor: '#1e293b',
      lmTextColor: '#f1f5f9',
      lmAccentColor: '#6366f1',
    }, resolve);
  });
}

async function getIdiomsForLM() {
  return new Promise(resolve => {
    chrome.storage.sync.get(['idiomCsv'], async (result) => {
      let idioms = [];
      try {
        let csv = result.idiomCsv;
        if (!csv) {
          const url = chrome.runtime.getURL('idiom.csv');
          const resp = await fetch(url);
          csv = await resp.text();
        }

        // Robust CSV parser: handles quoted fields, multi-column, CRLF
        function parseCSVLine(line) {
          const fields = [];
          let cur = '', inQ = false;
          for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (ch === '"') {
              if (inQ && line[i+1] === '"') { cur += '"'; i++; }
              else inQ = !inQ;
            } else if (ch === ',' && !inQ) {
              fields.push(cur.trim()); cur = '';
            } else {
              cur += ch;
            }
          }
          fields.push(cur.trim());
          return fields;
        }

        const lines = csv.split(/\r?\n/).filter(l => l.trim());
        let isFirst = true;
        for (const line of lines) {
          const fields = parseCSVLine(line);
          const idiom = fields[0] || '';
          const definition = fields[1] || '';
          // Skip header row (first line or if idiom looks like a column header)
          if (isFirst) {
            isFirst = false;
            if (/^(idiom|phrase|expression|word|term)s?$/i.test(idiom)) continue;
          }
          // Skip empty or obviously non-idiom rows
          if (!idiom || idiom.length > 100) continue;
          // Strip any HTML tags that may have leaked in
          const cleanIdiom = idiom.replace(/<[^>]*>/g, '').trim();
          const cleanDef   = definition.replace(/<[^>]*>/g, '').trim();
          if (cleanIdiom) idioms.push({ idiom: cleanIdiom, definition: cleanDef });
        }
      } catch (e) {
        console.warn('LM: could not load idioms', e);
      }
      resolve(idioms);
    });
  });
}

// Auto-start if learning mode was previously enabled
(async function autoStartLearningMode() {
  const settings = await getSettingsForLM();
  if (settings.learningModeEnabled) {
    await initOrToggleLearningMode(true);
  }
})();
