document.addEventListener('DOMContentLoaded', function() {

  // Safe wrapper – silently swallows "no receiving end" errors
  function safeSend(tabId, msg, cb) {
    try {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        void chrome.runtime.lastError; // consume to suppress uncaught error
        if (cb) cb(resp);
      });
    } catch(e) { /* tab not injectable */ }
  }

  function withActiveTab(fn) {
    chrome.tabs.query({active:true, currentWindow:true}, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) fn(tabs[0]);
    });
  }


  // ── Local PDF detection ────────────────────────────────────────────────────
  (function detectLocalPDF() {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0]) return;
      const url = tabs[0].url || '';
      const isPdf = /\.pdf(\?|#|$)/i.test(url) || url.startsWith('file://');
      const isLocalOrRemotePdf = isPdf && !url.startsWith(chrome.runtime.getURL(''));
      const banner = document.getElementById('pdf-banner');
      if (isLocalOrRemotePdf && banner) banner.style.display = 'block';
    });
  })();

  // "Open in Viewer" button
  const openInViewerBtn = document.getElementById('openInViewerBtn');
  if (openInViewerBtn) {
    openInViewerBtn.addEventListener('click', () => {
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        if (!tabs[0]) return;
        const fileUrl = tabs[0].url;
        const viewerUrl = chrome.runtime.getURL('pdf-viewer.html') +
                          '?file=' + encodeURIComponent(fileUrl);
        chrome.tabs.update(tabs[0].id, { url: viewerUrl });
        window.close();
      });
    });
  }

  // Tab switching
  const tabBtns = document.querySelectorAll('.tab-btn');
  const panels  = document.querySelectorAll('.panel');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabName = btn.dataset.tab;
      tabBtns.forEach(b => b.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(tabName + 'Panel').classList.add('active');
      if (tabName === 'list') loadStats();
    });
  });

  loadStats();
  loadSettings();
  updateFileInfo();

  document.getElementById('refreshBtn').addEventListener('click', () => {
    withActiveTab(t => safeSend(t.id, {action:'refresh'}, ()=>setTimeout(loadStats,500)));
  });

  document.getElementById('refreshStats').addEventListener('click', (e) => {
    e.preventDefault();
    loadStats();
  });

  document.getElementById('clearHighlightsBtn').addEventListener('click', () => {
    withActiveTab(t => safeSend(t.id, {action:'clearHighlights'}, ()=>loadStats()));
  });

  document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);
  document.getElementById('loadDefaultBtn').addEventListener('click', loadDefaultIdioms);
  document.getElementById('csvFile').addEventListener('change', handleFileUpload);

  const testNotionBtn = document.getElementById('testNotionBtn');
  if (testNotionBtn) testNotionBtn.addEventListener('click', testNotionConnection);

  // ── Learning Mode UI wiring ───────────────────────────────────────────────

  function toggleLearningModeOptions(enabled) {
    const opts = document.getElementById('learningModeOptions');
    if (opts) opts.style.display = enabled ? '' : 'none';
  }

  const lmEnabledChk = document.getElementById('learningModeEnabled');
  if (lmEnabledChk) {
    lmEnabledChk.addEventListener('change', (e) => {
      toggleLearningModeOptions(e.target.checked);
      withActiveTab(t => safeSend(t.id, {action:'learningModeToggle', enabled:e.target.checked}));
    });
  }

  const lmFsSlider = document.getElementById('lmFontSize');
  if (lmFsSlider) lmFsSlider.addEventListener('input', (e) => {
    const lbl = document.getElementById('lmFontSizeLabel');
    if (lbl) lbl.textContent = e.target.value + 'px';
  });

  const lmResetBtn = document.getElementById('lmResetProgressBtn');
  if (lmResetBtn) lmResetBtn.addEventListener('click', () => {
    chrome.storage.local.remove(['wthDailyReviewed', 'wthLastReviewDate'], () => {
      showPopupMessage('✅ Learning Mode progress reset', 'success');
    });
  });

  const lmPreviewBtn = document.getElementById('lmPreviewBtn');
  if (lmPreviewBtn) lmPreviewBtn.addEventListener('click', () => {
    withActiveTab(t => safeSend(t.id, {action:'learningModePreview'}));
    window.close();
  });

  // ── Load settings ─────────────────────────────────────────────────────────
  function loadSettings() {
    chrome.storage.sync.get({
      ankiEnabled: true,
      ankiUrl: 'http://localhost:8765',
      defaultDeck: 'English Idioms',
      defaultModel: 'Basic',
      aiEnabled: true,
      aiProvider: 'openai',
      aiApiKey: '',
      customApiUrl: '',
      customModel: '',
      customPrompt: 'Please analyze this English idiom: "{idiom}"\n\nContext where it was found: "{context}"\n\nProvide the following in a clear, structured format:\nMEANING: A simple, clear definition\nUSAGE: When and how to use it\nEXAMPLE: One original example sentence\nORIGIN: Brief origin if known\nSIMILAR: Any similar idioms or expressions',
      notionEnabled: false,
      notionApiKey: '',
      notionDatabaseId: '',
      idiomCsv: '',
      translateEnabled: true,
      translateProvider: 'google_free',
      translateSourceLang: 'auto',
      translateTargetLang: 'zh-CN',
      translateLangConfigured: false,
      translateApiKey: '',
      translateApiKey2: '',
      translateApiUrl: '',
      learningModeEnabled: false,
      lmDailyLimit: 20,
      lmFontSize: 14,
      lmBgColor: '#1e293b',
      lmTextColor: '#f1f5f9',
      lmAccentColor: '#6366f1',
    }, (items) => {
      if (chrome.runtime.lastError) {
        console.error('Error loading settings:', chrome.runtime.lastError);
        showPopupMessage('Error loading settings', 'error');
        return;
      }

      // Anki
      const ankiEnabled = document.getElementById('ankiEnabled');
      if (ankiEnabled) ankiEnabled.checked = items.ankiEnabled;
      const ankiUrl = document.getElementById('ankiUrl');
      if (ankiUrl) ankiUrl.value = items.ankiUrl;
      const defaultDeck = document.getElementById('defaultDeck');
      if (defaultDeck) defaultDeck.value = items.defaultDeck;
      const defaultModel = document.getElementById('defaultModel');
      if (defaultModel) defaultModel.value = items.defaultModel;

      // AI
      const aiEnabled = document.getElementById('aiEnabled');
      if (aiEnabled) aiEnabled.checked = items.aiEnabled;
      const aiProvider = document.getElementById('aiProvider');
      if (aiProvider) {
        aiProvider.value = items.aiProvider || 'openai';
        updateAIProviderUI(items.aiProvider || 'openai', false);
      }
      const aiApiKey = document.getElementById('aiApiKey');
      if (aiApiKey) aiApiKey.value = items.aiApiKey;
      const customApiUrl = document.getElementById('customApiUrl');
      if (customApiUrl) customApiUrl.value = items.customApiUrl;
      const customModel = document.getElementById('customModel');
      if (customModel) customModel.value = items.customModel;
      const customPrompt = document.getElementById('customPrompt');
      if (customPrompt) customPrompt.value = items.customPrompt;

      // Notion
      const notionEnabled = document.getElementById('notionEnabled');
      if (notionEnabled) notionEnabled.checked = items.notionEnabled;
      const notionApiKey = document.getElementById('notionApiKey');
      if (notionApiKey) notionApiKey.value = items.notionApiKey;
      const notionDatabaseId = document.getElementById('notionDatabaseId');
      if (notionDatabaseId) notionDatabaseId.value = items.notionDatabaseId;

      // Translation
      const translateEnabled = document.getElementById('translateEnabled');
      if (translateEnabled) translateEnabled.checked = items.translateEnabled;
      const translateSourceLang = document.getElementById('translateSourceLang');
      if (translateSourceLang) translateSourceLang.value = items.translateSourceLang || 'auto';
      const translateTargetLang = document.getElementById('translateTargetLang');
      if (translateTargetLang) translateTargetLang.value = items.translateTargetLang || 'zh-CN';
      const translateProvider = document.getElementById('translateProvider');
      if (translateProvider) {
        translateProvider.value = items.translateProvider || 'google_free';
        updateTranslateProviderUI(items.translateProvider || 'google_free');
      }
      const translateApiKey = document.getElementById('translateApiKey');
      if (translateApiKey) translateApiKey.value = items.translateApiKey;
      const translateApiKey2 = document.getElementById('translateApiKey2');
      if (translateApiKey2) translateApiKey2.value = items.translateApiKey2;
      const translateApiUrl = document.getElementById('translateApiUrl');
      if (translateApiUrl) translateApiUrl.value = items.translateApiUrl;

      // Learning Mode — inside callback so `items` is in scope
      const lmEnabled = document.getElementById('learningModeEnabled');
      if (lmEnabled) {
        lmEnabled.checked = items.learningModeEnabled;
        toggleLearningModeOptions(items.learningModeEnabled);
      }
      const lmDailyLimit = document.getElementById('lmDailyLimit');
      if (lmDailyLimit) lmDailyLimit.value = items.lmDailyLimit;
      const lmFs = document.getElementById('lmFontSize');
      if (lmFs) {
        lmFs.value = items.lmFontSize;
        const lbl = document.getElementById('lmFontSizeLabel');
        if (lbl) lbl.textContent = items.lmFontSize + 'px';
      }
      const lmBg = document.getElementById('lmBgColor');
      if (lmBg) lmBg.value = items.lmBgColor;
      const lmTxt = document.getElementById('lmTextColor');
      if (lmTxt) lmTxt.value = items.lmTextColor;
      const lmAcc = document.getElementById('lmAccentColor');
      if (lmAcc) lmAcc.value = items.lmAccentColor;
    }); // end chrome.storage.sync.get
  } // end loadSettings

  // ── Save settings ─────────────────────────────────────────────────────────
  function saveSettings() {
    const settings = {
      ankiEnabled: document.getElementById('ankiEnabled')?.checked ?? true,
      ankiUrl: document.getElementById('ankiUrl')?.value || 'http://localhost:8765',
      defaultDeck: document.getElementById('defaultDeck')?.value || 'English Idioms',
      defaultModel: document.getElementById('defaultModel')?.value || 'Basic',
      aiEnabled: document.getElementById('aiEnabled')?.checked ?? true,
      aiProvider: document.getElementById('aiProvider')?.value || 'openai',
      aiApiKey: document.getElementById('aiApiKey')?.value || '',
      customApiUrl: document.getElementById('customApiUrl')?.value || '',
      customModel: document.getElementById('customModel')?.value || '',
      customPrompt: document.getElementById('customPrompt')?.value || '',
      notionEnabled: document.getElementById('notionEnabled')?.checked ?? false,
      notionApiKey: document.getElementById('notionApiKey')?.value || '',
      notionDatabaseId: document.getElementById('notionDatabaseId')?.value || '',
      translateEnabled: document.getElementById('translateEnabled')?.checked ?? true,
      translateProvider: document.getElementById('translateProvider')?.value || 'google_free',
      translateSourceLang: document.getElementById('translateSourceLang')?.value || 'auto',
      translateTargetLang: document.getElementById('translateTargetLang')?.value || 'zh-CN',
      translateLangConfigured: true,
      translateApiKey: document.getElementById('translateApiKey')?.value || '',
      translateApiKey2: document.getElementById('translateApiKey2')?.value || '',
      translateApiUrl: document.getElementById('translateApiUrl')?.value || '',
      learningModeEnabled: document.getElementById('learningModeEnabled')?.checked ?? false,
      lmDailyLimit: parseInt(document.getElementById('lmDailyLimit')?.value) || 20,
      lmFontSize: parseInt(document.getElementById('lmFontSize')?.value) || 14,
      lmBgColor: document.getElementById('lmBgColor')?.value || '#1e293b',
      lmTextColor: document.getElementById('lmTextColor')?.value || '#f1f5f9',
      lmAccentColor: document.getElementById('lmAccentColor')?.value || '#6366f1',
    };

    chrome.storage.sync.set(settings, () => {
      if (chrome.runtime.lastError) {
        showPopupMessage('❌ Error saving settings: ' + chrome.runtime.lastError.message, 'error');
      } else {
        showPopupMessage('✅ Settings saved successfully!', 'success');
        const lmSett = {
          dailyLimit: settings.lmDailyLimit,
          fontSize: settings.lmFontSize,
          bgColor: settings.lmBgColor,
          textColor: settings.lmTextColor,
          accentColor: settings.lmAccentColor,
        };
        withActiveTab(t => {
          safeSend(t.id, {action:'learningModeToggle', enabled:settings.learningModeEnabled});
          safeSend(t.id, {action:'learningModeUpdate', settings:lmSett});
        });
        const btn = document.getElementById('saveSettingsBtn');
        if (btn) {
          const originalText = btn.innerHTML;
          btn.innerHTML = '<span class="btn-icon">✅</span><span class="btn-text">Saved!</span>';
          btn.style.background = '#10b981';
          setTimeout(() => { btn.innerHTML = originalText; btn.style.background = ''; }, 2000);
        }
      }
    });
  }

  // ── showPopupMessage ──────────────────────────────────────────────────────
  function showPopupMessage(message, type) {
    const notification = document.createElement('div');
    notification.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);background:' +
      (type === 'success' ? '#10b981' : '#ef4444') +
      ';color:white;padding:8px 16px;border-radius:4px;font-size:12px;z-index:10000;box-shadow:0 2px 4px rgba(0,0,0,.2);';
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 2000);
  }

  // ── handleFileUpload ──────────────────────────────────────────────────────
  function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      chrome.storage.sync.set({idiomCsv: e.target.result}, () => {
        if (chrome.runtime.lastError) {
          showPopupMessage('❌ Error uploading file', 'error');
        } else {
          document.getElementById('fileInfo').textContent = '✅ Loaded: ' + file.name + ' (' + file.size + ' bytes)';
          showPopupMessage('✅ CSV file loaded successfully!', 'success');
          document.querySelector('[data-tab="list"]')?.click();
          withActiveTab(t => chrome.tabs.reload(t.id));
        }
      });
    };
    reader.readAsText(file);
  }

  // ── updateFileInfo ────────────────────────────────────────────────────────
  function updateFileInfo() {
    chrome.storage.sync.get(['idiomCsv'], (result) => {
      const fileInfo = document.getElementById('fileInfo');
      const idiomCount = document.getElementById('idiomCount');
      if (result.idiomCsv) {
        const lineCount = result.idiomCsv.split('\n').filter(l => l.trim()).length - 1;
        if (fileInfo) fileInfo.textContent = '✅ ' + lineCount + ' custom idioms loaded';
        if (idiomCount) idiomCount.textContent = lineCount;
      } else {
        if (fileInfo) fileInfo.textContent = '📁 Using default idioms (100+)';
        if (idiomCount) idiomCount.textContent = '100+';
      }
    });
  }

  // ── loadDefaultIdioms ─────────────────────────────────────────────────────
  function loadDefaultIdioms() {
    chrome.storage.sync.remove('idiomCsv', () => {
      if (chrome.runtime.lastError) {
        showPopupMessage('❌ Error loading default idioms', 'error');
      } else {
        const fileInfo = document.getElementById('fileInfo');
        if (fileInfo) fileInfo.textContent = '✅ Default idioms loaded';
        const idiomCount = document.getElementById('idiomCount');
        if (idiomCount) idiomCount.textContent = '100+';
        showPopupMessage('✅ Default idioms loaded!', 'success');
        document.querySelector('[data-tab="list"]')?.click();
        withActiveTab(t => chrome.tabs.reload(t.id));
      }
    });
  }

  // ── testNotionConnection ──────────────────────────────────────────────────
  async function testNotionConnection() {
    const apiKey = document.getElementById('notionApiKey')?.value;
    const databaseId = document.getElementById('notionDatabaseId')?.value;
    if (!apiKey || !databaseId) {
      showPopupMessage('❌ Please enter both Notion API Key and Database ID', 'error');
      return;
    }
    const btn = document.getElementById('testNotionBtn');
    if (!btn) return;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-text">Testing...</span>';
    btn.disabled = true;
    try {
      const response = await fetch('https://api.notion.com/v1/databases/' + databaseId, {
        method: 'GET',
        headers: { 'Authorization': 'Bearer ' + apiKey, 'Notion-Version': '2022-06-28' }
      });
      if (response.ok) {
        const data = await response.json();
        const dbName = data.title[0]?.plain_text || 'Unnamed Database';
        showPopupMessage('✅ Connection successful! Database: ' + dbName, 'success');
      } else {
        const error = await response.json();
        showPopupMessage('❌ Connection failed: ' + error.message, 'error');
      }
    } catch (error) {
      showPopupMessage('❌ Connection failed: ' + error.message, 'error');
    } finally {
      btn.innerHTML = originalText;
      btn.disabled = false;
    }
  }

  // ── loadStats ─────────────────────────────────────────────────────────────
  function loadStats() {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (!tabs[0]) return;
      safeSend(tabs[0].id, {action:'getStats'}, (response) => {
        if (response) updateStats(response);
      });
    });
  }

  // ── updateStats ───────────────────────────────────────────────────────────
  function updateStats(stats) {
    const totalCount = document.getElementById('totalCount');
    if (totalCount) totalCount.textContent = stats.count || 0;
    const uniqueCount = document.getElementById('uniqueCount');
    if (uniqueCount) uniqueCount.textContent = stats.uniqueCount || 0;
    const autoCount = document.getElementById('autoCount');
    if (autoCount) autoCount.textContent = stats.autoCount || 0;
    const userCount = document.getElementById('userCount');
    if (userCount) userCount.textContent = stats.userCount || 0;
    const idiomList = document.getElementById('idiomList');
    if (stats.idioms && stats.idioms.length > 0) {
      let html = '';
      stats.idioms.forEach(item => {
        html += '<div class="idiom-item"><div class="idiom-badge ' + item.type + '"></div><div class="idiom-content"><div class="idiom-main">' + item.idiom + '</div><div class="idiom-meta"><span>' + item.matched + '</span><span class="idiom-match">' + item.type + '</span></div></div></div>';
      });
      if (idiomList) idiomList.innerHTML = html;
    } else {
      if (idiomList) idiomList.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-text">No idioms found on this page</div><div style="font-size:11px;margin-top:8px;">Select text → Right-click → "✨ Highlight as Idiom"</div></div>';
    }
  }

}); // end DOMContentLoaded

// ── Translation provider UI toggle ───────────────────────────────────────────
function updateTranslateProviderUI(provider) {
  const keyRow   = document.getElementById('translateApiKeyRow');
  const key2Row  = document.getElementById('translateApiKey2Row');
  const urlRow   = document.getElementById('translateApiUrlRow');
  const keyHint  = document.getElementById('translateApiKeyHint');
  const key2Lbl  = document.getElementById('translateApiKey2Label');
  const key2Hint = document.getElementById('translateApiKey2Hint');
  if (!keyRow) return;
  keyRow.style.display = 'none';
  if (key2Row) key2Row.style.display = 'none';
  if (urlRow)  urlRow.style.display  = 'none';
  switch (provider) {
    case 'google':
      keyRow.style.display = '';
      if (keyHint) keyHint.innerHTML = 'Get a key at <a href="https://console.cloud.google.com/apis/library/translate.googleapis.com" target="_blank">Google Cloud Console</a>';
      break;
    case 'microsoft':
      keyRow.style.display = ''; if (key2Row) key2Row.style.display = '';
      if (keyHint) keyHint.innerHTML = 'Free 2M chars/mo at <a href="https://azure.microsoft.com/en-us/products/ai-services/ai-translator" target="_blank">Azure AI Translator</a>';
      if (key2Lbl) key2Lbl.textContent = 'Azure Region (e.g. eastus)';
      if (key2Hint) key2Hint.textContent = 'Find your region in Azure portal → Resource → Keys and Endpoint';
      break;
    case 'deepl':
      keyRow.style.display = '';
      if (keyHint) keyHint.innerHTML = 'Free 500K chars/mo at <a href="https://www.deepl.com/pro#developer" target="_blank">deepl.com</a>';
      break;
    case 'yandex':
      keyRow.style.display = '';
      if (keyHint) keyHint.innerHTML = 'Get key at <a href="https://translate.yandex.com/developers" target="_blank">Yandex Translate</a>';
      break;
    case 'baidu':
      keyRow.style.display = ''; if (key2Row) key2Row.style.display = '';
      if (keyHint) keyHint.innerHTML = 'AppID from <a href="https://fanyi-api.baidu.com/manage/developer" target="_blank">百度翻译开放平台</a>';
      if (key2Lbl) key2Lbl.textContent = 'Secret Key 密钥';
      if (key2Hint) key2Hint.textContent = 'Free: 1M chars/month';
      break;
    case 'libretranslate':
      keyRow.style.display = ''; if (urlRow) urlRow.style.display = '';
      if (keyHint) keyHint.textContent = 'API key optional for self-hosted; required for libretranslate.com';
      break;
    case 'custom':
      keyRow.style.display = ''; if (urlRow) urlRow.style.display = '';
      if (keyHint) keyHint.textContent = 'POST {text, source, target, api_key} → {translatedText}';
      break;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const ps = document.getElementById('translateProvider');
  if (ps) ps.addEventListener('change', (e) => updateTranslateProviderUI(e.target.value));
});

// ── AI Provider UI configuration ──────────────────────────────────────────────
const AI_PROVIDERS = {
  openai:     { label: 'OpenAI API Key',     placeholder: 'sk-...',       hint: 'Get your key at <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a>',              defaultModel: 'gpt-3.5-turbo',           modelHint: 'e.g. gpt-3.5-turbo, gpt-4o-mini, gpt-4o',                    showUrl: false },
  anthropic:  { label: 'Anthropic API Key',  placeholder: 'sk-ant-...',   hint: 'Get your key at <a href="https://console.anthropic.com/settings/keys" target="_blank">console.anthropic.com</a>',     defaultModel: 'claude-3-haiku-20240307', modelHint: 'e.g. claude-3-5-haiku-20241022, claude-3-5-sonnet-20241022',  showUrl: false },
  gemini:     { label: 'Google AI API Key',  placeholder: 'AIza...',      hint: 'Get your key at <a href="https://aistudio.google.com/app/apikey" target="_blank">Google AI Studio</a> — free tier',  defaultModel: 'gemini-1.5-flash',        modelHint: 'e.g. gemini-1.5-flash, gemini-1.5-pro, gemini-2.0-flash',    showUrl: false },
  deepseek:   { label: 'DeepSeek API Key',   placeholder: 'sk-...',       hint: 'Get your key at <a href="https://platform.deepseek.com/api_keys" target="_blank">platform.deepseek.com</a>',         defaultModel: 'deepseek-chat',           modelHint: 'e.g. deepseek-chat, deepseek-reasoner',                       showUrl: false },
  mistral:    { label: 'Mistral API Key',    placeholder: 'Your key...',  hint: 'Get your key at <a href="https://console.mistral.ai/api-keys" target="_blank">console.mistral.ai</a>',              defaultModel: 'mistral-small-latest',    modelHint: 'e.g. mistral-small-latest, mistral-large-latest',             showUrl: false },
  groq:       { label: 'Groq API Key',       placeholder: 'gsk_...',      hint: 'Free key at <a href="https://console.groq.com/keys" target="_blank">console.groq.com</a> — fast inference',         defaultModel: 'llama-3.1-8b-instant',    modelHint: 'e.g. llama-3.1-8b-instant, mixtral-8x7b-32768',               showUrl: false },
  openrouter: { label: 'OpenRouter API Key', placeholder: 'sk-or-...',    hint: 'Get your key at <a href="https://openrouter.ai/keys" target="_blank">openrouter.ai</a> — 200+ models',              defaultModel: 'openai/gpt-4o-mini',      modelHint: 'e.g. openai/gpt-4o-mini, anthropic/claude-3-haiku',           showUrl: false },
  ollama:     { label: 'API Key (optional)', placeholder: 'Not required', hint: 'Ollama runs locally — no key needed. Install from <a href="https://ollama.ai" target="_blank">ollama.ai</a>.<br><br>⚠️ Start Ollama with this command:<br><code style="display:block;margin-top:6px;padding:6px 10px;background:#1e293b;color:#f1f5f9;border-radius:6px;font-size:11px;user-select:all;">pkill ollama && OLLAMA_ORIGINS="*" ollama serve</code>',       defaultModel: 'gemma3:4b',                modelHint: 'e.g. llama3.2, mistral, qwen2.5, phi3',                       showUrl: true, urlPlaceholder: 'http://127.0.0.1:11434/v1/chat/completions', urlHint: 'Default: http://127.0.0.1:11434/v1/chat/completions' },
  custom:     { label: 'API Key',            placeholder: 'Your API key', hint: 'API key for your custom endpoint',                                                                                   defaultModel: '',                        modelHint: 'Model name accepted by your endpoint',                        showUrl: true, urlPlaceholder: 'https://your-api.com/v1/chat/completions', urlHint: 'Must accept OpenAI-compatible chat completions format' },
};

function updateAIProviderUI(provider, clearModel) {
  if (clearModel === undefined) clearModel = true;
  const cfg = AI_PROVIDERS[provider] || AI_PROVIDERS.custom;
  const keyRow    = document.getElementById('aiApiKeyRow');
  const keyLabel  = document.getElementById('aiApiKeyLabel');
  const keyInput  = document.getElementById('aiApiKey');
  const keyHint   = document.getElementById('aiApiKeyHint');
  const urlRow    = document.getElementById('aiApiUrlRow');
  const urlInput  = document.getElementById('customApiUrl');
  const urlHint   = document.getElementById('aiApiUrlHint');
  const modelInput = document.getElementById('customModel');
  const modelHint  = document.getElementById('aiModelHint');
  if (keyLabel) keyLabel.textContent = cfg.label;
  if (keyInput) keyInput.placeholder = cfg.placeholder;
  if (keyHint)  keyHint.innerHTML    = cfg.hint || '';
  if (urlRow)   urlRow.style.display = cfg.showUrl ? '' : 'none';
  if (urlInput && cfg.urlPlaceholder) urlInput.placeholder = cfg.urlPlaceholder;
  if (urlHint  && cfg.urlHint)        urlHint.textContent  = cfg.urlHint;
  if (modelInput && clearModel && !modelInput.value) modelInput.value = cfg.defaultModel;
  if (modelHint) modelHint.textContent = cfg.modelHint || '';
}

document.addEventListener('DOMContentLoaded', () => {
  const ps = document.getElementById('aiProvider');
  if (ps) ps.addEventListener('change', (e) => updateAIProviderUI(e.target.value, true));
});

// ── Chat Tab ────────────────────────────────────────────────────────────────
(function initChat() {
  const messagesEl = document.getElementById('chatMessages');
  const inputEl    = document.getElementById('chatInput');
  const sendBtn    = document.getElementById('chatSendBtn');
  const statusEl   = document.getElementById('chatStatus');
  if (!messagesEl || !inputEl || !sendBtn) return;

  // conversation history for multi-turn context
  const history = [];

  function appendMessage(role, text) {
    const div = document.createElement('div');
    div.className = 'chat-msg chat-msg--' + role;
    div.style.cssText = [
      'align-self:' + (role === 'user' ? 'flex-end' : 'flex-start'),
      'background:' + (role === 'user' ? '#4f46e5' : '#1e293b'),
      'color:#e2e8f0',
      'padding:8px 12px',
      'border-radius:10px',
      'font-size:13px',
      'line-height:1.5',
      'max-width:90%',
      'white-space:pre-wrap',
      'word-break:break-word',
    ].join(';');
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return div;
  }

  async function sendMessage() {
    const text = inputEl.value.trim();
    if (!text) return;

    appendMessage('user', text);
    history.push({ role: 'user', content: text });
    inputEl.value = '';
    sendBtn.disabled = true;
    statusEl.textContent = '⏳ Thinking…';

    // Load AI settings from storage
    chrome.storage.sync.get({
      aiEnabled: true,
      aiProvider: 'openai',
      aiApiKey: '',
      customApiUrl: '',
      customModel: '',
    }, async (items) => {
      if (!items.aiEnabled) {
        appendMessage('assistant', '⚠️ AI is disabled. Please enable it in Settings.');
        statusEl.textContent = '';
        sendBtn.disabled = false;
        return;
      }
      if (!items.aiApiKey && items.aiProvider !== 'ollama') {
        appendMessage('assistant', '⚠️ No API key found. Please configure it in Settings.');
        statusEl.textContent = '';
        sendBtn.disabled = false;
        return;
      }

      // Resolve endpoint & model using same provider config as popup
      const providerCfg = {
        openai:     { url: 'https://api.openai.com/v1/chat/completions',                       defaultModel: 'gpt-3.5-turbo' },
        anthropic:  { url: 'https://api.anthropic.com/v1/messages',                            defaultModel: 'claude-3-haiku-20240307' },
        gemini:     { url: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions', defaultModel: 'gemini-1.5-flash' },
        deepseek:   { url: 'https://api.deepseek.com/v1/chat/completions',                     defaultModel: 'deepseek-chat' },
        mistral:    { url: 'https://api.mistral.ai/v1/chat/completions',                       defaultModel: 'mistral-small-latest' },
        groq:       { url: 'https://api.groq.com/openai/v1/chat/completions',                  defaultModel: 'llama-3.1-8b-instant' },
        openrouter: { url: 'https://openrouter.ai/api/v1/chat/completions',                    defaultModel: 'openai/gpt-4o-mini' },
        ollama:     { url: items.customApiUrl || 'http://127.0.0.1:11434/v1/chat/completions', defaultModel: 'gemma3:4b' },
        custom:     { url: items.customApiUrl || '',                                            defaultModel: '' },
      };
      const cfg = providerCfg[items.aiProvider] || providerCfg.openai;
      const apiUrl = (items.aiProvider === 'ollama' || items.aiProvider === 'custom')
                     ? (items.customApiUrl || cfg.url)
                     : cfg.url;
      const model = items.customModel || cfg.defaultModel;

      const body = {
        model,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          ...history,
        ],
        temperature: 0.7,
        max_tokens: 800,
      };

      const headers = { 'Content-Type': 'application/json' };
      if (items.aiProvider !== 'ollama' || items.aiApiKey) {
        headers['Authorization'] = 'Bearer ' + items.aiApiKey;
      }

      try {
        const resp = await fetch(apiUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify(body),
        });
        if (!resp.ok) {
          const errText = await resp.text();
          throw new Error('HTTP ' + resp.status + ': ' + errText.slice(0, 120));
        }
        const json = await resp.json();
        const reply = json.choices?.[0]?.message?.content || '(no response)';
        history.push({ role: 'assistant', content: reply });
        appendMessage('assistant', reply);
        statusEl.textContent = '';
      } catch (err) {
        appendMessage('assistant', '❌ Error: ' + err.message);
        statusEl.textContent = '';
        history.pop(); // remove failed user turn from history
      } finally {
        sendBtn.disabled = false;
      }
    });
  }

  sendBtn.addEventListener('click', sendMessage);
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
})();
